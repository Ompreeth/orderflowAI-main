OrderFlow AI — experiment and test artefacts
============================================

Put test_orderflow.py in the project folder (next to app.py) and run:

    python -m pytest test_orderflow.py -v          # 34 tests, needs no DB and no Ollama

eval_parser.py and orderflow_corpus.json are already in C:\orderflowAI-main.
To produce the zero-shot numbers for Table 7.2 of the report, start Ollama and run:

    python eval_parser.py --limit 40               # quick smoke test first
    python eval_parser.py --runs 3                 # the real measurement

Send me the three files it writes (eval_results.json, eval_per_item.csv,
eval_confusion_matrix.csv) and I will fill in Table 7.2 and the RQ1 paragraph.

The remaining files reproduce every supervised number and figure in the report:

    python build_corpus.py        # validates the corpus, writes eda_stats.json
    python train_models.py        # trains all 7 models, writes model_results.json + 6 figures

Requires scikit-learn, numpy and matplotlib. Fixed seed 42, so the results are
bit-for-bit repeatable.
