# -*- coding: utf-8 -*-
"""
Train and evaluate the supervised intent classifiers for OrderFlow AI.

Protocol
--------
  * stratified 70 / 15 / 15 train / validation / test split, seed 42
  * model selection by 5-fold stratified CV grid search on train+validation
  * the test split is touched exactly once, at the end, for the final figures
  * every number this prints lands in Chapters 4, 6 and 7 of the report

Outputs: model_results.json plus the figures listed at the bottom.
"""
import json
import os
import platform
import re
import sys
import time
from collections import Counter

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import sklearn
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, classification_report,
                             confusion_matrix, f1_score, precision_recall_fscore_support)
from sklearn.model_selection import (GridSearchCV, StratifiedKFold, learning_curve,
                                     train_test_split, cross_val_score)
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import FeatureUnion, Pipeline
from sklearn.preprocessing import FunctionTransformer
from sklearn.svm import LinearSVC

HERE = os.path.dirname(os.path.abspath(__file__))
SEED = 42
np.random.seed(SEED)

INTENTS = ["create_order", "update_status", "query_order", "list_orders", "log_quality",
           "list_inventory", "query_inventory", "consume_stock", "report_query"]

# print-safe, colourblind-checked categorical order (fixed, never cycled)
CAT = ["#2B5C8A", "#C2570B", "#4A7C3F", "#8B3A62", "#6B6B8F"]
INK = "#1A1A1A"
MUTED = "#6E6E6E"
GRID = "#D8D8D8"

plt.rcParams.update({
    "font.size": 9, "axes.titlesize": 10, "axes.labelsize": 9,
    "axes.edgecolor": MUTED, "axes.labelcolor": INK, "text.color": INK,
    "xtick.color": MUTED, "ytick.color": MUTED,
    "axes.spines.top": False, "axes.spines.right": False,
    "figure.dpi": 150, "savefig.bbox": "tight",
})

RULE_PHRASES = (
    "inventory value", "inventory worth", "value of inventory", "how much is our inventory",
    "how much is the inventory", "fulfillment time", "how long do orders take",
    "average fulfillment", "order fulfillment", "how many open orders", "open orders",
    "orders are open", "outstanding orders", "best supplier", "top supplier",
    "supplier scorecard", "which supplier is best", "low stock", "low on stock",
    "stockout risk", "what's running low", "whats running low", "running low",
    "what's low", "whats low",
)


# ── 4.10 entity masking ────────────────────────────────────────────────
# The error analysis on the unmasked models showed the failure mode plainly:
# "order welding rod 200kg" (create_order) and "remaining quantity of welding
# rod" (query_inventory) share every high-weight token, because the catalogue
# noun carries far more tf-idf mass than the verb that actually separates the
# two intents. Nine of the fourteen first-pass test errors were of exactly
# this shape. Collapsing catalogue nouns to a single <PART> symbol, order
# references to <OID> and bare integers to <NUM> forces the model onto the
# action words, which is where the intent genuinely lives.
CATALOGUE_TOKENS = {
    "steel", "rods", "rod", "aluminum", "aluminium", "alluminum", "alluminium", "sheets",
    "sheet", "copper", "coper", "wire", "spool", "spools", "ball", "balls", "bearings",
    "bearing", "rubber", "gaskets", "gasket", "hex", "bolts", "bolt", "m8", "nuts", "nut",
    "plastic", "casings", "casing", "circuit", "circut", "boards", "board", "motor",
    "housings", "housing", "hydraulic", "hoses", "hose", "welding", "paint", "cans", "can",
    "packaging", "boxes", "box", "conveyor", "conveyer", "belts", "belt", "stel", "rails",
}
_ORDER_REF = re.compile(r"\border\s+(?:number\s+|no\.?\s+|#)?(\d+)", re.I)
_ORD_REF = re.compile(r"\bord\s+(\d+)", re.I)
_BARE_NUM = re.compile(r"\d+")
_PART_RUN = re.compile(r"(?:<part>\s*)+")


def mask_entities(text):
    t = text.lower()
    t = _ORDER_REF.sub("order <oid>", t)
    t = _ORD_REF.sub("order <oid>", t)
    t = _BARE_NUM.sub("<num>", t)
    out = []
    for tok in re.findall(r"<[a-z]+>|[a-z']+|[^\sa-z<>']", t):
        out.append("<part>" if tok in CATALOGUE_TOKENS else tok)
    t = " ".join(out)
    return _PART_RUN.sub("<part> ", t).strip()


def short(name):
    return {"create_order": "create", "update_status": "upd_status", "query_order": "qry_order",
            "list_orders": "list_ord", "log_quality": "quality", "list_inventory": "list_inv",
            "query_inventory": "qry_inv", "consume_stock": "consume",
            "report_query": "report"}[name]


def main():
    corpus = json.load(open(os.path.join(HERE, "orderflow_corpus.json"), encoding="utf-8"))
    X = np.array([r["text"] for r in corpus])
    y = np.array([r["intent"] for r in corpus])
    results = {"seed": SEED, "environment": {
        "python": sys.version.split()[0], "sklearn": sklearn.__version__,
        "numpy": np.__version__, "platform": platform.platform(),
    }}

    # ── 4.12 split ──────────────────────────────────────────────────────
    X_tr, X_tmp, y_tr, y_tmp = train_test_split(
        X, y, test_size=0.30, stratify=y, random_state=SEED)
    X_val, X_te, y_val, y_te = train_test_split(
        X_tmp, y_tmp, test_size=0.50, stratify=y_tmp, random_state=SEED)
    X_dev = np.concatenate([X_tr, X_val]); y_dev = np.concatenate([y_tr, y_val])

    results["split"] = {
        "train": len(X_tr), "validation": len(X_val), "test": len(X_te),
        "dev_for_gridsearch": len(X_dev),
        "train_distribution": dict(Counter(y_tr).most_common()),
        "test_distribution": dict(Counter(y_te).most_common()),
    }
    print(f"split  train={len(X_tr)}  val={len(X_val)}  test={len(X_te)}")

    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=SEED)

    # ── 5.10 baselines ──────────────────────────────────────────────────
    dummy = DummyClassifier(strategy="most_frequent").fit(X_dev, y_dev)
    maj_acc = accuracy_score(y_te, dummy.predict(X_te))

    # the deterministic keyword fallback, scored as a detector for report_query
    rule_pred = np.array(["report_query" if any(p in t.lower() for p in RULE_PHRASES)
                          else "ABSTAIN" for t in X_te])
    fired = rule_pred == "report_query"
    rule_tp = int(((y_te == "report_query") & fired).sum())
    rule_fp = int(((y_te != "report_query") & fired).sum())
    rule_total_rq = int((y_te == "report_query").sum())
    results["baselines"] = {
        "majority_class": {"name": dummy.classes_[0] if hasattr(dummy, "classes_") else None,
                           "test_accuracy": round(maj_acc, 4)},
        "rule_based_fallback": {
            "fired_on": int(fired.sum()), "true_positives": rule_tp, "false_positives": rule_fp,
            "report_query_in_test": rule_total_rq,
            "precision": round(rule_tp / max(1, int(fired.sum())), 4),
            "recall": round(rule_tp / max(1, rule_total_rq), 4),
            "test_accuracy_as_9class": round(accuracy_score(y_te, rule_pred), 4),
        },
    }
    print(f"majority-class test accuracy: {maj_acc:.4f}")
    print(f"rule fallback: fired {int(fired.sum())}, TP {rule_tp}, FP {rule_fp} of {rule_total_rq} report queries")

    # ── 5.5 / 5.8 candidate models and grids ────────────────────────────
    word = lambda: TfidfVectorizer(sublinear_tf=True, min_df=1)
    candidates = {
        "MultinomialNB": (
            Pipeline([("tfidf", word()), ("clf", MultinomialNB())]),
            {"tfidf__ngram_range": [(1, 1), (1, 2)], "clf__alpha": [0.1, 0.3, 1.0]},
        ),
        "LogisticRegression": (
            Pipeline([("tfidf", word()),
                      ("clf", LogisticRegression(max_iter=2000, class_weight="balanced",
                                                 random_state=SEED))]),
            {"tfidf__ngram_range": [(1, 1), (1, 2)], "clf__C": [1.0, 4.0, 10.0]},
        ),
        "LinearSVC": (
            Pipeline([("tfidf", word()),
                      ("clf", LinearSVC(class_weight="balanced", random_state=SEED))]),
            {"tfidf__ngram_range": [(1, 1), (1, 2)], "clf__C": [0.5, 1.0, 4.0]},
        ),
        "RandomForest": (
            Pipeline([("tfidf", word()),
                      ("clf", RandomForestClassifier(class_weight="balanced",
                                                     random_state=SEED, n_jobs=-1))]),
            {"tfidf__ngram_range": [(1, 1)], "clf__n_estimators": [300, 600],
             "clf__min_samples_leaf": [1, 2]},
        ),
        # 4.10 feature engineering: word n-grams plus character n-grams, so a
        # misspelling like "stel rods" still shares sub-word evidence with
        # "steel rods" even though the word unigram misses entirely.
        "LogReg + char n-grams": (
            Pipeline([("feats", FeatureUnion([
                ("w", TfidfVectorizer(sublinear_tf=True, ngram_range=(1, 2))),
                ("c", TfidfVectorizer(analyzer="char_wb", sublinear_tf=True, ngram_range=(3, 5))),
            ])),
                ("clf", LogisticRegression(max_iter=3000, class_weight="balanced",
                                           random_state=SEED))]),
            {"clf__C": [4.0, 10.0, 20.0]},
        ),
        "LogReg + masking": (
            Pipeline([("mask", FunctionTransformer(
                lambda xs: [mask_entities(x) for x in xs], validate=False)),
                ("feats", FeatureUnion([
                    ("w", TfidfVectorizer(sublinear_tf=True, ngram_range=(1, 3),
                                          token_pattern=r"(?u)<[a-z]+>|\b\w+\b")),
                    ("c", TfidfVectorizer(analyzer="char_wb", sublinear_tf=True,
                                          ngram_range=(3, 5))),
                ])),
                ("clf", LogisticRegression(max_iter=4000, class_weight="balanced",
                                           random_state=SEED))]),
            {"clf__C": [4.0, 10.0, 20.0]},
        ),
        "LinearSVC + masking": (
            Pipeline([("mask", FunctionTransformer(
                lambda xs: [mask_entities(x) for x in xs], validate=False)),
                ("feats", FeatureUnion([
                    ("w", TfidfVectorizer(sublinear_tf=True, ngram_range=(1, 3),
                                          token_pattern=r"(?u)<[a-z]+>|\b\w+\b")),
                    ("c", TfidfVectorizer(analyzer="char_wb", sublinear_tf=True,
                                          ngram_range=(3, 5))),
                ])),
                ("clf", LinearSVC(class_weight="balanced", random_state=SEED))]),
            {"clf__C": [0.5, 1.0, 4.0]},
        ),
    }

    table, fitted = {}, {}
    for name, (pipe, grid) in candidates.items():
        t0 = time.perf_counter()
        gs = GridSearchCV(pipe, grid, cv=cv, scoring="f1_macro", n_jobs=-1)
        gs.fit(X_dev, y_dev)
        fit_s = time.perf_counter() - t0

        best = gs.best_estimator_
        cv_scores = cross_val_score(best, X_dev, y_dev, cv=cv, scoring="f1_macro", n_jobs=-1)

        t1 = time.perf_counter()
        pred = best.predict(X_te)
        pred_ms = (time.perf_counter() - t1) * 1000 / len(X_te)

        p, r, f1, _ = precision_recall_fscore_support(y_te, pred, average="macro", zero_division=0)
        table[name] = {
            "best_params": {k: (list(v) if isinstance(v, tuple) else v)
                            for k, v in gs.best_params_.items()},
            "cv_f1_macro_mean": round(float(cv_scores.mean()), 4),
            "cv_f1_macro_std": round(float(cv_scores.std()), 4),
            "cv_folds": [round(float(s), 4) for s in cv_scores],
            "test_accuracy": round(float(accuracy_score(y_te, pred)), 4),
            "test_precision_macro": round(float(p), 4),
            "test_recall_macro": round(float(r), 4),
            "test_f1_macro": round(float(f1), 4),
            "test_f1_weighted": round(float(f1_score(y_te, pred, average="weighted", zero_division=0)), 4),
            "grid_fit_seconds": round(fit_s, 2),
            "inference_ms_per_utterance": round(pred_ms, 4),
            "n_features": int(len(best[:-1].transform(X_dev[:1]).toarray()[0])),
        }
        fitted[name] = best
        print(f"{name:24s} CV f1={cv_scores.mean():.4f}±{cv_scores.std():.4f}  "
              f"test acc={table[name]['test_accuracy']:.4f}  f1={f1:.4f}  "
              f"({fit_s:.1f}s grid, {pred_ms:.3f} ms/utt)")

    results["models"] = table
    results["masking_examples"] = [
        {"raw": str(t), "masked": mask_entities(str(t)), "intent": str(lab)}
        for t, lab in list(zip(X, y))[:0] or []
    ] + [{"raw": r, "masked": mask_entities(r), "intent": i}
         for r, i in [("order welding rod 200kg", "create_order"),
                      ("remaining quantity of welding rod", "query_inventory"),
                      ("we burned through 80 kg of welding rods", "consume_stock"),
                      ("mark order 14 as accepted", "update_status"),
                      ("what's the status of order 14", "query_order")]]
    results["masking_ablation"] = {
        "LogReg + char n-grams (unmasked)": table["LogReg + char n-grams"]["cv_f1_macro_mean"],
        "LogReg + masking": table["LogReg + masking"]["cv_f1_macro_mean"],
        "LinearSVC (unmasked)": table["LinearSVC"]["cv_f1_macro_mean"],
        "LinearSVC + masking": table["LinearSVC + masking"]["cv_f1_macro_mean"],
    }
    champion = max(table, key=lambda k: table[k]["cv_f1_macro_mean"])
    results["champion"] = champion
    print(f"\nchampion by CV macro-F1: {champion}")

    best = fitted[champion]
    pred = best.predict(X_te)

    # ── 7.6 per-class metrics and confusion matrix ──────────────────────
    rep = classification_report(y_te, pred, labels=INTENTS, output_dict=True, zero_division=0)
    results["champion_per_class"] = {
        k: {m: round(float(v2), 4) for m, v2 in v.items()}
        for k, v in rep.items() if k in INTENTS
    }
    cm = confusion_matrix(y_te, pred, labels=INTENTS)
    results["champion_confusion_matrix"] = {"labels": INTENTS, "matrix": cm.tolist()}

    # ── 7.11 error analysis ─────────────────────────────────────────────
    errs = [{"text": str(t), "true": str(a), "pred": str(b)}
            for t, a, b in zip(X_te, y_te, pred) if a != b]
    results["test_errors"] = errs
    print(f"test errors: {len(errs)}/{len(X_te)}")
    for e in errs:
        print(f"  {e['true']:16s} -> {e['pred']:16s}  {e['text']!r}")

    # cross-validated errors give a far bigger error pool to reason about
    from sklearn.model_selection import cross_val_predict
    cvp = cross_val_predict(best, X_dev, y_dev, cv=cv, n_jobs=-1)
    cv_errs = [{"text": str(t), "true": str(a), "pred": str(b)}
               for t, a, b in zip(X_dev, y_dev, cvp) if a != b]
    results["cv_accuracy_on_dev"] = round(float(accuracy_score(y_dev, cvp)), 4)
    results["cv_errors"] = cv_errs
    results["cv_confusion_matrix"] = {
        "labels": INTENTS,
        "matrix": confusion_matrix(y_dev, cvp, labels=INTENTS).tolist()}
    print(f"dev CV accuracy: {results['cv_accuracy_on_dev']:.4f}  ({len(cv_errs)} errors / {len(y_dev)})")

    # ── 7.10 feature importance (interpretable linear champion) ─────────
    lin = fitted.get("LogisticRegression")
    if lin is not None:
        vec, clf = lin.named_steps["tfidf"], lin.named_steps["clf"]
        names = np.array(vec.get_feature_names_out())
        top = {}
        for i, cls in enumerate(clf.classes_):
            idx = np.argsort(clf.coef_[i])[::-1][:8]
            top[cls] = [[names[j], round(float(clf.coef_[i][j]), 3)] for j in idx]
        results["top_features_logreg"] = top
        results["logreg_vocabulary"] = int(len(names))

    # ═══════════════════════ figures ════════════════════════════════════
    eda = json.load(open(os.path.join(HERE, "eda_stats.json"), encoding="utf-8"))

    # Fig: class distribution (one series -> no legend, title names it)
    fig, ax = plt.subplots(figsize=(6.0, 2.9))
    d = eda["class_distribution"]
    ks = list(d.keys()); vs = [d[k] for k in ks]
    bars = ax.bar([short(k) for k in ks], vs, color=CAT[0], width=0.62)
    for b, v in zip(bars, vs):
        ax.text(b.get_x() + b.get_width() / 2, v + 0.8, str(v), ha="center", fontsize=8, color=INK)
    ax.set_ylabel("utterances"); ax.set_ylim(0, max(vs) * 1.18)
    ax.set_title("Corpus class distribution (n = %d)" % eda["n_items"], loc="left")
    ax.yaxis.grid(True, color=GRID, lw=0.6); ax.set_axisbelow(True)
    plt.setp(ax.get_xticklabels(), rotation=28, ha="right")
    fig.savefig(os.path.join(HERE, "fig_class_distribution.png")); plt.close(fig)

    # Fig: utterance length histogram
    fig, ax = plt.subplots(figsize=(5.4, 2.6))
    lens = [len(r["text"].split()) for r in corpus]
    ax.hist(lens, bins=range(min(lens), max(lens) + 2), color=CAT[0],
            edgecolor="white", linewidth=0.8, align="left")
    ax.axvline(float(np.mean(lens)), color=CAT[1], lw=2, ls="--")
    ax.text(float(np.mean(lens)) + 0.15, ax.get_ylim()[1] * 0.88,
            "mean %.2f" % float(np.mean(lens)), color=CAT[1], fontsize=8)
    ax.set_xlabel("tokens per utterance"); ax.set_ylabel("utterances")
    ax.set_title("Utterance length distribution", loc="left")
    ax.yaxis.grid(True, color=GRID, lw=0.6); ax.set_axisbelow(True)
    fig.savefig(os.path.join(HERE, "fig_token_length.png")); plt.close(fig)

    # Fig: model comparison, CV vs test (2 series -> legend present)
    fig, ax = plt.subplots(figsize=(6.3, 3.0))
    names = list(table.keys())
    xs = np.arange(len(names)); w = 0.36
    cvm = [table[n]["cv_f1_macro_mean"] for n in names]
    cvs = [table[n]["cv_f1_macro_std"] for n in names]
    tst = [table[n]["test_f1_macro"] for n in names]
    ax.bar(xs - w / 2, cvm, w, yerr=cvs, capsize=3, color=CAT[0], label="5-fold CV macro-F1",
           error_kw={"lw": 1, "ecolor": MUTED})
    ax.bar(xs + w / 2, tst, w, color=CAT[1], label="held-out test macro-F1")
    ax.axhline(maj_acc, color=MUTED, ls=":", lw=1.2,
               label="majority-class baseline (%.3f)" % maj_acc)
    ax.set_xticks(xs); ax.set_xticklabels(names, rotation=22, ha="right")
    ax.set_ylabel("macro-F1"); ax.set_ylim(0, 1.06)
    ax.set_title("Classifier comparison", loc="left")
    ax.yaxis.grid(True, color=GRID, lw=0.6); ax.set_axisbelow(True)
    ax.legend(frameon=False, fontsize=8, loc="upper left", bbox_to_anchor=(0.005, 1.0))
    fig.savefig(os.path.join(HERE, "fig_model_comparison.png")); plt.close(fig)

    # Fig: confusion matrix (sequential, one hue, light -> dark)
    fig, ax = plt.subplots(figsize=(5.6, 4.9))
    m = np.array(results["cv_confusion_matrix"]["matrix"])
    im = ax.imshow(m, cmap="Blues", vmin=0, vmax=m.max())
    ax.set_xticks(range(9)); ax.set_yticks(range(9))
    ax.set_xticklabels([short(i) for i in INTENTS], rotation=40, ha="right", fontsize=8)
    ax.set_yticklabels([short(i) for i in INTENTS], fontsize=8)
    for i in range(9):
        for j in range(9):
            if m[i, j]:
                ax.text(j, i, m[i, j], ha="center", va="center", fontsize=8,
                        color="white" if m[i, j] > m.max() * 0.55 else INK)
    ax.set_xlabel("predicted"); ax.set_ylabel("actual")
    ax.set_title("%s — 5-fold cross-validated confusion matrix" % champion, loc="left", fontsize=9)
    fig.colorbar(im, ax=ax, shrink=0.78, label="utterances")
    fig.savefig(os.path.join(HERE, "fig_confusion_matrix.png")); plt.close(fig)

    # Fig: learning curve
    fig, ax = plt.subplots(figsize=(5.4, 2.9))
    sizes, tr_sc, te_sc = learning_curve(
        best, X_dev, y_dev, cv=cv, scoring="f1_macro", n_jobs=-1,
        train_sizes=np.linspace(0.2, 1.0, 6), random_state=SEED)
    ax.plot(sizes, tr_sc.mean(1), "-o", color=CAT[0], lw=2, ms=4, label="training")
    ax.fill_between(sizes, tr_sc.mean(1) - tr_sc.std(1), tr_sc.mean(1) + tr_sc.std(1),
                    color=CAT[0], alpha=0.13, lw=0)
    ax.plot(sizes, te_sc.mean(1), "-s", color=CAT[1], lw=2, ms=4, label="cross-validation")
    ax.fill_between(sizes, te_sc.mean(1) - te_sc.std(1), te_sc.mean(1) + te_sc.std(1),
                    color=CAT[1], alpha=0.13, lw=0)
    ax.set_xlabel("training utterances"); ax.set_ylabel("macro-F1"); ax.set_ylim(0, 1.05)
    ax.set_title("Learning curve — %s" % champion, loc="left")
    ax.yaxis.grid(True, color=GRID, lw=0.6); ax.set_axisbelow(True)
    ax.legend(frameon=False, fontsize=8, loc="lower right")
    fig.savefig(os.path.join(HERE, "fig_learning_curve.png")); plt.close(fig)
    results["learning_curve"] = {
        "train_sizes": [int(s) for s in sizes],
        "train_f1": [round(float(v), 4) for v in tr_sc.mean(1)],
        "cv_f1": [round(float(v), 4) for v in te_sc.mean(1)],
    }

    # Fig: per-part corpus coverage
    fig, ax = plt.subplots(figsize=(5.6, 3.2))
    pp = eda["catalogue_coverage"]["per_part"]
    kk = list(pp.keys())[::-1]; vv = [pp[k] for k in kk]
    ax.barh(kk, vv, color=CAT[2], height=0.62)
    for i, v in enumerate(vv):
        ax.text(v + 0.25, i, str(v), va="center", fontsize=8, color=INK)
    ax.set_xlabel("utterances referencing the part")
    ax.set_title("Catalogue coverage across the corpus", loc="left")
    ax.xaxis.grid(True, color=GRID, lw=0.6); ax.set_axisbelow(True)
    ax.set_xlim(0, max(vv) * 1.16)
    plt.setp(ax.get_yticklabels(), fontsize=8)
    fig.savefig(os.path.join(HERE, "fig_catalogue_coverage.png")); plt.close(fig)

    with open(os.path.join(HERE, "model_results.json"), "w", encoding="utf-8") as fh:
        json.dump(results, fh, ensure_ascii=False, indent=1)
    print("\nwrote model_results.json and 6 figures")


if __name__ == "__main__":
    main()
