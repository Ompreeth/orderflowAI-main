# -*- coding: utf-8 -*-
"""
Assemble, validate and describe the OrderFlow AI intent corpus.

Emits:
    orderflow_corpus.json   the corpus itself
    eda_stats.json          everything Chapter 4 reports about it
"""
import json
import os
import re
import statistics as st
from collections import Counter, defaultdict

from corpus_a import ITEMS_A
from corpus_b import ITEMS_B

HERE = os.path.dirname(os.path.abspath(__file__))

INTENTS = ["create_order", "update_status", "query_order", "list_orders", "log_quality",
           "list_inventory", "query_inventory", "consume_stock", "report_query"]

CATALOGUE = ["Steel Rods", "Aluminum Sheets", "Copper Wire Spool", "Ball Bearings",
             "Rubber Gaskets", "Hex Bolts M8", "Hex Nuts M8", "Plastic Casings",
             "Circuit Boards", "Motor Housings", "Hydraulic Hoses", "Welding Rods",
             "Paint Cans", "Packaging Boxes", "Conveyor Belts"]

STATUSES = ["Received", "In Review", "Accepted"]

# Verbatim from answer_report_query() in app.py — the deterministic fallback
# that serves reporting questions when Ollama is unreachable.
RULE_PHRASES = {
    "inventory_value": ("inventory value", "inventory worth", "value of inventory",
                        "how much is our inventory", "how much is the inventory"),
    "fulfillment":     ("fulfillment time", "how long do orders take", "average fulfillment",
                        "order fulfillment"),
    "open_orders":     ("how many open orders", "open orders", "orders are open",
                        "outstanding orders"),
    "best_supplier":   ("best supplier", "top supplier", "supplier scorecard",
                        "which supplier is best"),
    "low_stock":       ("low stock", "low on stock", "stockout risk", "what's running low",
                        "whats running low", "running low", "what's low", "whats low"),
}


def rule_match(text):
    t = (text or "").lower()
    for bucket, phrases in RULE_PHRASES.items():
        if any(p in t for p in phrases):
            return bucket
    return None


def main():
    raw = list(ITEMS_A) + list(ITEMS_B)
    records, seen = [], {}

    for i, row in enumerate(raw):
        text, intent, part, qty, oid, status, deadline, lang = row

        assert intent in INTENTS, f"[{i}] unknown intent {intent!r}"
        assert part is None or part in CATALOGUE, f"[{i}] non-canonical part {part!r}"
        assert status is None or status in STATUSES, f"[{i}] bad status {status!r}"
        assert text.strip(), f"[{i}] empty text"

        key = text.strip().lower()
        assert key not in seen, f"[{i}] duplicate of item {seen[key]}: {text!r}"
        seen[key] = i

        records.append({
            "id": i + 1,
            "text": text,
            "intent": intent,
            "part_name": part,
            "quantity": qty,
            "order_id": oid,
            "new_status": status,
            "has_deadline": deadline,
            "lang": lang,
            "rule_bucket": rule_match(text) if intent == "report_query" else None,
        })

    # ── descriptive statistics for Chapter 4 ────────────────────────────
    by_intent = Counter(r["intent"] for r in records)
    by_lang = Counter(r["lang"] for r in records)
    lengths = [len(r["text"].split()) for r in records]
    chars = [len(r["text"]) for r in records]

    vocab = Counter()
    for r in records:
        vocab.update(re.findall(r"[a-z0-9']+", r["text"].lower()))

    # token-length distribution per intent — feeds the EDA boxplot
    len_by_intent = defaultdict(list)
    for r in records:
        len_by_intent[r["intent"]].append(len(r["text"].split()))

    slot_presence = {
        "part_name":  sum(1 for r in records if r["part_name"]),
        "quantity":   sum(1 for r in records if r["quantity"] is not None),
        "order_id":   sum(1 for r in records if r["order_id"] is not None),
        "new_status": sum(1 for r in records if r["new_status"]),
        "deadline":   sum(1 for r in records if r["has_deadline"]),
    }

    parts = Counter(r["part_name"] for r in records if r["part_name"])

    rq = [r for r in records if r["intent"] == "report_query"]
    rq_en = [r for r in rq if r["lang"] == "en"]
    rule_cov_en = sum(1 for r in rq_en if r["rule_bucket"])

    stats = {
        "n_items": len(records),
        "n_intents": len(INTENTS),
        "class_distribution": dict(by_intent.most_common()),
        "imbalance_ratio": round(max(by_intent.values()) / min(by_intent.values()), 2),
        "language_distribution": dict(by_lang.most_common()),
        "non_english_items": sum(v for k, v in by_lang.items() if k != "en"),
        "token_length": {
            "mean": round(st.mean(lengths), 2),
            "median": st.median(lengths),
            "stdev": round(st.pstdev(lengths), 2),
            "min": min(lengths),
            "max": max(lengths),
        },
        "char_length": {
            "mean": round(st.mean(chars), 2),
            "min": min(chars),
            "max": max(chars),
        },
        "token_length_by_intent": {
            k: {"mean": round(st.mean(v), 2), "min": min(v), "max": max(v)}
            for k, v in sorted(len_by_intent.items())
        },
        "vocabulary_size": len(vocab),
        "total_tokens": sum(vocab.values()),
        "hapax_legomena": sum(1 for w, c in vocab.items() if c == 1),
        "top_tokens": vocab.most_common(20),
        "slot_presence": slot_presence,
        "catalogue_coverage": {"referenced_parts": len(parts), "catalogue_size": len(CATALOGUE),
                               "per_part": dict(parts.most_common())},
        "rule_baseline": {
            "report_query_total": len(rq),
            "report_query_english": len(rq_en),
            "english_covered_by_rules": rule_cov_en,
            "english_coverage_pct": round(100 * rule_cov_en / len(rq_en), 1),
            "buckets_hit": dict(Counter(r["rule_bucket"] for r in rq_en if r["rule_bucket"])),
        },
    }

    with open(os.path.join(HERE, "orderflow_corpus.json"), "w", encoding="utf-8") as fh:
        json.dump(records, fh, ensure_ascii=False, indent=1)
    with open(os.path.join(HERE, "eda_stats.json"), "w", encoding="utf-8") as fh:
        json.dump(stats, fh, ensure_ascii=False, indent=1)

    print(f"corpus: {stats['n_items']} items, {stats['n_intents']} intents")
    print("class distribution:", stats["class_distribution"])
    print("imbalance ratio:", stats["imbalance_ratio"])
    print("languages:", stats["language_distribution"])
    print("tokens/utterance: mean %(mean)s median %(median)s range %(min)s-%(max)s" % stats["token_length"])
    print("vocabulary:", stats["vocabulary_size"], "types /", stats["total_tokens"], "tokens; hapax:", stats["hapax_legomena"])
    print("slots present:", stats["slot_presence"])
    print("parts referenced:", stats["catalogue_coverage"]["referenced_parts"], "of", len(CATALOGUE))
    print("rule baseline covers %(english_covered_by_rules)s/%(report_query_english)s English report queries (%(english_coverage_pct)s%%)" % stats["rule_baseline"])


if __name__ == "__main__":
    main()
